// Content data
const allContent = {
    'Games': ['Snake Game', 'Trivia', 'Motle', 'Guessr', 'Ascend'],
    'Resources': ['Events', 'Translate', 'Rewards', 'News', 'Cafe', 'Cuisine AI'],
    'Development': ['Homepage', 'Contact', 'Videos', 'Forms']
};

// DOM Elements
const categoriesContainer = document.getElementById('categories');
const buttonsContainer = document.getElementById('buttons-container');
const contentFrame = document.getElementById('content-frame');
const darkModeToggle = document.getElementById('dark-mode-toggle');

// State
let currentCategory = null;

// Functions
function createCategoryButtons() {
    Object.keys(allContent).forEach(category => {
        const button = document.createElement('button');
        button.textContent = category;
        button.classList.add('category-btn');
        button.addEventListener('click', () => loadCategoryContent(category));
        categoriesContainer.appendChild(button);
    });
}

function loadCategoryContent(category) {
    if (currentCategory === category) return;
    
    currentCategory = category;
    updateActiveButton(category);
    
    const items = allContent[category];
    
    buttonsContainer.innerHTML = items.map(item => createButtonHTML(item)).join('');
    contentFrame.src = 'about:blank';
}

function createButtonHTML(item) {
    const url = `https://dupuis.lol/${item.toLowerCase().replace(/\s+/g, '-')}`;
    return `
        <button class="button" data-url="${url}">
            ${item}
        </button>
    `;
}

function updateActiveButton(activeCategory) {
    document.querySelectorAll('.category-btn').forEach(btn => {
        btn.classList.toggle('active', btn.textContent === activeCategory);
    });
}

function handleButtonClick(event) {
    if (event.target.classList.contains('button')) {
        const url = event.target.dataset.url;
        contentFrame.src = url;
    }
}

function toggleDarkMode() {
    document.body.classList.toggle('dark-mode', darkModeToggle.checked);
    localStorage.setItem('darkMode', darkModeToggle.checked);
}

function initDarkMode() {
    const isDarkMode = localStorage.getItem('darkMode') === 'true';
    darkModeToggle.checked = isDarkMode;
    document.body.classList.toggle('dark-mode', isDarkMode);
}

// Event Listeners
buttonsContainer.addEventListener('click', handleButtonClick);
darkModeToggle.addEventListener('change', toggleDarkMode);

// Initialization
function init() {
    createCategoryButtons();
    loadCategoryContent(Object.keys(allContent)[0]);
    initDarkMode();
}

document.addEventListener('DOMContentLoaded', init);

// Add this line at the end of the file
export { allContent };