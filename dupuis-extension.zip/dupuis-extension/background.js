chrome.runtime.onInstalled.addListener(() => {
  console.log('dupuis.lol extension installed');
});

chrome.action.onClicked.addListener((tab) => {
  chrome.action.setPopup({tabId: tab.id, popup: 'popup.html'});
});